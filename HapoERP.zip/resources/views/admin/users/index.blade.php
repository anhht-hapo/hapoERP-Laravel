@extends('admin.layouts.master')
@section('content')
    <h1>Alo</h1>
    <h2>alo alo mes</h2>
    <a class="btn btn-success">anh</a>
@endsection

